<nav class="navbar navbar-expand-lg navbar-dark bg-dark"> 
    <div class="container">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" 
        data-bs-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" 
        aria-expanded="false" aria-label="Toggle navigation"> 
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <li class="nav-item me-3"> 
                <a class="nav-link" href="../adminpanel">Beranda</a> 
            </li>
            <li class="nav-item me-3"> 
                <a class="nav-link" href="facility.php">Kategori</a> 
            </li>
            <li class="nav-item me-3"> 
                <a class="nav-link" href="service.php">Service</a>
            </li>
            <li class="nav-item me-3">
                <a class="nav-link" href="..//index.php">Log out</a>
            </li>
        </ul>
</div>
</div>
</nav>






